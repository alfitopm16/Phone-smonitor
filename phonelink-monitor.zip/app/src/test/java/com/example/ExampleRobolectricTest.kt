package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.telemetry.HardwareTelemetryProvider
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("PhoneLink Monitor", appName)
  }

  @Test
  fun `hardware telemetry provider generates valid json structure`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val provider = HardwareTelemetryProvider(context)

    val jsonString = provider.buildStatusJsonResponse()
    assertNotNull(jsonString)

    val json = JSONObject(jsonString)
    assertTrue(json.has("device"))
    assertTrue(json.has("status"))
    assertTrue(json.has("timestamp"))
    assertTrue(json.has("battery"))
    assertTrue(json.has("thermal"))

    val battery = json.getJSONObject("battery")
    assertTrue(battery.has("level"))
    assertTrue(battery.has("temperature"))
    assertTrue(battery.has("voltage"))
    assertTrue(battery.has("current"))
    assertTrue(battery.has("power"))
    assertTrue(battery.has("charging"))
    assertTrue(battery.has("health"))

    val thermal = json.getJSONObject("thermal")
    assertTrue(thermal.has("batteryTemperature"))
    assertTrue(thermal.has("cpuTemperature"))
    assertTrue(thermal.has("gpuTemperature"))
    assertTrue(thermal.has("thermalStatus"))
  }
}
