package com.example.server

import android.content.Context
import android.os.PowerManager
import android.util.Log
import com.example.model.DeviceStatus
import com.example.telemetry.HardwareTelemetryProvider
import com.example.utils.NetworkUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ServerState(
    val isRunning: Boolean = false,
    val port: Int = 8080,
    val localIps: List<String> = emptyList(),
    val requestCount: Int = 0,
    val lastClientIp: String? = null,
    val lastRequestTime: String? = null,
    val currentTelemetry: DeviceStatus? = null,
    val errorMessage: String? = null
)

class MonitorHttpServer(
    private val context: Context,
    externalScope: CoroutineScope? = null
) {
    private val TAG = "MonitorHttpServer"
    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null

    private val serverJobParent = SupervisorJob()
    private val scope = externalScope ?: CoroutineScope(Dispatchers.IO + serverJobParent)

    private val telemetryProvider = HardwareTelemetryProvider(context.applicationContext)
    private val powerManager = context.applicationContext.getSystemService(Context.POWER_SERVICE) as? PowerManager

    private val _state = MutableStateFlow(ServerState())
    val state: StateFlow<ServerState> = _state.asStateFlow()

    init {
        refreshNetworkInfo()
    }

    fun refreshNetworkInfo() {
        val ips = NetworkUtils.getLocalIpAddresses()
        val currentTelemetry = telemetryProvider.getCurrentDeviceStatus()
        _state.update {
            it.copy(
                localIps = ips,
                currentTelemetry = currentTelemetry
            )
        }
    }

    @Synchronized
    fun start(port: Int = 8080) {
        if (_state.value.isRunning && serverSocket != null && !serverSocket!!.isClosed) {
            Log.d(TAG, "Server already running on port ${_state.value.port}")
            return
        }

        refreshNetworkInfo()
        serverJob?.cancel()

        serverJob = scope.launch(Dispatchers.IO) {
            try {
                val socket = ServerSocket()
                socket.reuseAddress = true
                socket.bind(InetSocketAddress("0.0.0.0", port))
                serverSocket = socket

                _state.update {
                    it.copy(
                        isRunning = true,
                        port = port,
                        errorMessage = null
                    )
                }
                Log.d(TAG, "HTTP Server successfully started on 0.0.0.0:$port")

                while (isActive && !socket.isClosed) {
                    try {
                        val clientSocket = socket.accept()
                        launch(Dispatchers.IO) {
                            handleClient(clientSocket)
                        }
                    } catch (e: Exception) {
                        if (!socket.isClosed) {
                            Log.w(TAG, "Error accepting client connection: ${e.message}")
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to start HTTP server on port $port: ${e.message}", e)
                _state.update {
                    it.copy(
                        isRunning = false,
                        errorMessage = "Gagal memulai server pada port $port: ${e.localizedMessage}"
                    )
                }
            }
        }
    }

    @Synchronized
    fun stop() {
        try {
            serverJob?.cancel()
            serverJob = null
            serverSocket?.close()
            serverSocket = null
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping server: ${e.message}")
        } finally {
            _state.update { it.copy(isRunning = false) }
            Log.d(TAG, "HTTP Server stopped")
        }
    }

    private suspend fun handleClient(socket: Socket) {
        val clientIp = socket.inetAddress?.hostAddress ?: "Unknown"

        // Ephemeral wakelock only for the brief duration of processing the request (max 3 sec timeout)
        // This ensures screen-off stability without preventing CPU sleep permanently.
        val wakeLock = try {
            powerManager?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "phonelink:handle_req")?.apply {
                setReferenceCounted(false)
                acquire(3000L)
            }
        } catch (e: Exception) {
            null
        }

        withContext(Dispatchers.IO) {
            try {
                socket.soTimeout = 4000
                val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
                val outputStream = socket.getOutputStream()

                val requestLine = reader.readLine()
                if (requestLine != null) {
                    val parts = requestLine.split(" ")
                    val method = if (parts.isNotEmpty()) parts[0] else "GET"
                    val path = if (parts.size > 1) parts[1] else "/"

                    var headerLine: String? = reader.readLine()
                    while (!headerLine.isNullOrEmpty()) {
                        headerLine = reader.readLine()
                    }

                    val now = System.currentTimeMillis()
                    val timeFormatted = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(now))

                    if (method.equals("OPTIONS", ignoreCase = true)) {
                        sendOptionsResponse(outputStream)
                    } else if (path == "/api/status" || path == "/" || path.startsWith("/api/status")) {
                        // Real hardware telemetry response (computed strictly on-demand)
                        val jsonResponse = telemetryProvider.buildStatusJsonResponse()
                        val currentTelemetry = telemetryProvider.getCurrentDeviceStatus()

                        sendJsonResponse(outputStream, 200, "OK", jsonResponse)

                        _state.update {
                            it.copy(
                                requestCount = it.requestCount + 1,
                                lastClientIp = clientIp,
                                lastRequestTime = timeFormatted,
                                currentTelemetry = currentTelemetry
                            )
                        }
                    } else {
                        val notFoundJson = JSONObject().apply {
                            put("error", "Not Found")
                            put("available_endpoints", listOf("/api/status"))
                        }.toString()
                        sendJsonResponse(outputStream, 404, "Not Found", notFoundJson)
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error handling client $clientIp: ${e.message}")
            } finally {
                try {
                    socket.close()
                } catch (ignored: Exception) {}

                try {
                    if (wakeLock?.isHeld == true) {
                        wakeLock.release()
                    }
                } catch (ignored: Exception) {}
            }
        }
    }

    private fun sendJsonResponse(out: OutputStream, statusCode: Int, statusText: String, body: String) {
        val bodyBytes = body.toByteArray(Charsets.UTF_8)
        val header = StringBuilder()
            .append("HTTP/1.1 $statusCode $statusText\r\n")
            .append("Content-Type: application/json; charset=utf-8\r\n")
            .append("Content-Length: ${bodyBytes.size}\r\n")
            .append("Access-Control-Allow-Origin: *\r\n")
            .append("Access-Control-Allow-Methods: GET, OPTIONS\r\n")
            .append("Access-Control-Allow-Headers: Content-Type\r\n")
            .append("Connection: close\r\n\r\n")
            .toString()

        out.write(header.toByteArray(Charsets.UTF_8))
        out.write(bodyBytes)
        out.flush()
    }

    private fun sendOptionsResponse(out: OutputStream) {
        val header = StringBuilder()
            .append("HTTP/1.1 204 No Content\r\n")
            .append("Access-Control-Allow-Origin: *\r\n")
            .append("Access-Control-Allow-Methods: GET, OPTIONS\r\n")
            .append("Access-Control-Allow-Headers: Content-Type\r\n")
            .append("Content-Length: 0\r\n")
            .append("Connection: close\r\n\r\n")
            .toString()

        out.write(header.toByteArray(Charsets.UTF_8))
        out.flush()
    }
}
