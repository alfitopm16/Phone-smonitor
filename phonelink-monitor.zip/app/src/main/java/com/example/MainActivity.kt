package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.DashboardScreen
import com.example.ui.HomeScreen
import com.example.ui.MonitorScreen
import com.example.ui.components.AboutDialog
import com.example.ui.components.AppSettingsDialog
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                PhoneLinkApp(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhoneLinkApp(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentMode by viewModel.currentMode.collectAsStateWithLifecycle()
    val serverState by viewModel.serverState.collectAsStateWithLifecycle()
    val dashboardState by viewModel.dashboardState.collectAsStateWithLifecycle()
    val historyLogs by viewModel.historyLogs.collectAsStateWithLifecycle()
    val selectedTimeRange by viewModel.selectedTimeRange.collectAsStateWithLifecycle()
    val activeAlerts by viewModel.activeAlerts.collectAsStateWithLifecycle()
    val alertSettings by viewModel.alertSettings.collectAsStateWithLifecycle()

    var showSettingsDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }

    // Request Notification permission on Android 13+ when entering Dashboard mode
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(currentMode) {
        if ((currentMode == AppMode.DASHBOARD || currentMode == AppMode.MONITOR) && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val hasPermission = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!hasPermission) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    // App Settings Modal Dialog
    if (showSettingsDialog) {
        AppSettingsDialog(
            deviceName = dashboardState.deviceStatus?.device ?: "Phone 1",
            targetIp = dashboardState.targetIp,
            serverPort = dashboardState.port,
            autoReconnect = dashboardState.autoReconnect,
            alertSettings = alertSettings,
            onDismiss = { showSettingsDialog = false },
            onSaveSettings = { deviceName, targetIp, serverPort, autoReconnect, newAlertSettings ->
                viewModel.dashboardClient.updateTargetIp(targetIp)
                viewModel.dashboardClient.updatePort(serverPort)
                viewModel.dashboardClient.toggleAutoReconnect(autoReconnect)
                viewModel.updateAlertSettings(newAlertSettings)
                showSettingsDialog = false
                Toast.makeText(context, "Pengaturan berhasil disimpan", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // About Modal Dialog
    if (showAboutDialog) {
        AboutDialog(
            onDismiss = { showAboutDialog = false }
        )
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            if (currentMode != AppMode.MODE_SELECTION) {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = if (currentMode == AppMode.MONITOR) "Monitor Mode (HP 1)" else "Dashboard Mode (HP 2)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "PhoneLink Monitor",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = { viewModel.backToSelection() },
                            modifier = Modifier.testTag("btn_back_to_selection")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Kembali ke pemilihan mode"
                            )
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { showSettingsDialog = true },
                            modifier = Modifier.testTag("topbar_btn_settings")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Settings"
                            )
                        }
                        IconButton(
                            onClick = { showAboutDialog = true },
                            modifier = Modifier.testTag("topbar_btn_about")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = "About"
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }
        }
    ) { innerPadding ->
        Crossfade(
            targetState = currentMode,
            modifier = Modifier.padding(innerPadding),
            label = "mode_crossfade"
        ) { mode ->
            when (mode) {
                AppMode.MODE_SELECTION -> {
                    HomeScreen(
                        serverState = serverState,
                        dashboardState = dashboardState,
                        onSelectMonitorMode = { viewModel.selectMode(AppMode.MONITOR) },
                        onSelectDashboardMode = { viewModel.selectMode(AppMode.DASHBOARD) },
                        onOpenSettings = { showSettingsDialog = true },
                        onOpenAbout = { showAboutDialog = true }
                    )
                }
                AppMode.MONITOR -> {
                    MonitorScreen(
                        state = serverState,
                        onToggleServer = { viewModel.toggleServer() },
                        onRefreshIps = { viewModel.refreshNetworkIps() }
                    )
                }
                AppMode.DASHBOARD -> {
                    DashboardScreen(
                        state = dashboardState,
                        historyLogs = historyLogs,
                        selectedTimeRange = selectedTimeRange,
                        onTimeRangeSelected = { viewModel.selectTimeRange(it) },
                        activeAlerts = activeAlerts,
                        alertSettings = alertSettings,
                        onSaveAlertSettings = { viewModel.updateAlertSettings(it) },
                        onIpChange = { viewModel.dashboardClient.updateTargetIp(it) },
                        onPortChange = { viewModel.dashboardClient.updatePort(it) },
                        onAutoReconnectChange = { viewModel.dashboardClient.toggleAutoReconnect(it) },
                        onConnect = { viewModel.dashboardClient.connect() },
                        onDisconnect = { viewModel.dashboardClient.disconnect() }
                    )
                }
            }
        }
    }
}
