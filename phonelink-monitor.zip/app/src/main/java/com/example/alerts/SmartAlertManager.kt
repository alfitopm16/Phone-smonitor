package com.example.alerts

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.model.DeviceStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class AlertType {
    LOW_BATTERY,
    HIGH_TEMPERATURE
}

data class ActiveAlert(
    val type: AlertType,
    val title: String,
    val message: String,
    val valueString: String,
    val timestamp: Long = System.currentTimeMillis()
)

class SmartAlertManager(private val context: Context) {

    private val TAG = "SmartAlertManager"
    val settingsManager = AlertSettingsManager(context)

    private val _activeAlerts = MutableStateFlow<List<ActiveAlert>>(emptyList())
    val activeAlerts: StateFlow<List<ActiveAlert>> = _activeAlerts.asStateFlow()

    private val _settings = MutableStateFlow(settingsManager.loadSettings())
    val settings: StateFlow<AlertSettings> = _settings.asStateFlow()

    private var lastLowBatteryNotifyTime: Long = 0L
    private var lastHighTempNotifyTime: Long = 0L

    companion object {
        const val CHANNEL_ID = "phonelink_alerts_channel"
        const val NOTIF_ID_LOW_BATTERY = 1001
        const val NOTIF_ID_HIGH_TEMP = 1002
    }

    init {
        createNotificationChannel()
    }

    fun updateSettings(newSettings: AlertSettings) {
        settingsManager.saveSettings(newSettings)
        _settings.value = newSettings
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "PhoneLink Smart Alerts"
            val descriptionText = "Notifications for battery and temperature threshold warnings"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
                enableVibration(true)
            }
            val notificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            notificationManager?.createNotificationChannel(channel)
        }
    }

    fun evaluateStatus(deviceStatus: DeviceStatus) {
        val currentSettings = _settings.value
        val now = System.currentTimeMillis()
        val cooldownMillis = currentSettings.cooldownMinutes * 60 * 1000L

        val newAlerts = mutableListOf<ActiveAlert>()

        val batteryLevel = deviceStatus.battery?.level
        val batteryTemp = deviceStatus.battery?.temperature
        val isCharging = deviceStatus.battery?.charging == true
        val deviceName = deviceStatus.device.ifEmpty { "Phone 1" }

        // 1. Evaluate Low Battery Condition (only if not currently charging to full or if explicitly low)
        if (batteryLevel != null && batteryLevel <= currentSettings.lowBatteryThreshold) {
            val alert = ActiveAlert(
                type = AlertType.LOW_BATTERY,
                title = "LOW BATTERY",
                message = "$deviceName battery is low.",
                valueString = "$batteryLevel% (Threshold: ${currentSettings.lowBatteryThreshold}%)",
                timestamp = now
            )
            newAlerts.add(alert)

            if (currentSettings.notificationsEnabled && (now - lastLowBatteryNotifyTime >= cooldownMillis)) {
                sendNotification(
                    id = NOTIF_ID_LOW_BATTERY,
                    title = "LOW BATTERY: $deviceName",
                    message = "$deviceName battery is low ($batteryLevel%). Segera lakukan pengisian daya."
                )
                lastLowBatteryNotifyTime = now
            }
        }

        // 2. Evaluate High Temperature Condition
        if (batteryTemp != null && batteryTemp >= currentSettings.highTempThreshold) {
            val alert = ActiveAlert(
                type = AlertType.HIGH_TEMPERATURE,
                title = "HIGH TEMPERATURE",
                message = "$deviceName temperature is high.",
                valueString = "${batteryTemp}°C (Threshold: ${currentSettings.highTempThreshold}°C)",
                timestamp = now
            )
            newAlerts.add(alert)

            if (currentSettings.notificationsEnabled && (now - lastHighTempNotifyTime >= cooldownMillis)) {
                sendNotification(
                    id = NOTIF_ID_HIGH_TEMP,
                    title = "HIGH TEMPERATURE: $deviceName",
                    message = "$deviceName temperature is high (${batteryTemp}°C). Suhu perangkat di atas batas aman."
                )
                lastHighTempNotifyTime = now
            }
        }

        _activeAlerts.value = newAlerts
    }

    fun clearAlerts() {
        _activeAlerts.value = emptyList()
    }

    private fun sendNotification(id: Int, title: String, message: String) {
        try {
            // Check POST_NOTIFICATIONS runtime permission on Android 13+ (API 33)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val hasPermission = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
                if (!hasPermission) {
                    Log.d(TAG, "Notification permission not granted, skipping system notification.")
                    return
                }
            }

            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pendingIntent = PendingIntent.getActivity(
                context,
                id,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val builder = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(NotificationCompat.BigTextStyle().bigText(message))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)

            NotificationManagerCompat.from(context).notify(id, builder.build())
        } catch (e: Throwable) {
            Log.e(TAG, "Error posting notification: ${e.message}")
        }
    }
}
