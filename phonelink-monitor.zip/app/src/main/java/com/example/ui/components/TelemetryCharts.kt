package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.db.HistoryTimeRange
import com.example.db.TelemetryLogEntity
import com.example.ui.theme.StatusOnline
import com.example.ui.theme.StatusWarning
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun RealtimeChartsSection(
    historyLogs: List<TelemetryLogEntity>,
    selectedTimeRange: HistoryTimeRange,
    onTimeRangeSelected: (HistoryTimeRange) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("realtime_charts_section"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Header & Time Range Selection
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Timeline,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = "Historical Real-time Trends",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                    ) {
                        Text(
                            text = "${historyLogs.size} points",
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Text(
                    text = "Time Range:",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Time Range Selector Tabs (1m, 5m, 15m, 1h)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    HistoryTimeRange.entries.forEach { range ->
                        val isSelected = range == selectedTimeRange
                        FilterChip(
                            selected = isSelected,
                            onClick = { onTimeRangeSelected(range) },
                            label = {
                                Text(
                                    text = range.label,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("chip_range_${range.name}"),
                            shape = RoundedCornerShape(10.dp),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            )
                        )
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))

            // 1. BATTERY TEMPERATURE GRAPH
            TelemetryLineGraph(
                title = "🌡 Battery Temperature Trend",
                unit = "°C",
                accentColor = Color(0xFFFB923C), // Warm orange
                dataPoints = historyLogs.mapNotNull { log ->
                    log.batteryTemperature?.let { temp -> Pair(log.timestamp, temp) }
                },
                minFixed = 25f,
                maxFixed = 55f,
                testTag = "chart_temperature"
            )

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.25f))

            // 2. BATTERY PERCENTAGE GRAPH
            TelemetryLineGraph(
                title = "🔋 Battery Percentage Trend",
                unit = "%",
                accentColor = Color(0xFF10B981), // Emerald green
                dataPoints = historyLogs.mapNotNull { log ->
                    log.batteryLevel?.let { level -> Pair(log.timestamp, level.toFloat()) }
                },
                minFixed = 0f,
                maxFixed = 100f,
                testTag = "chart_battery_level"
            )
        }
    }
}

@Composable
fun TelemetryLineGraph(
    title: String,
    unit: String,
    accentColor: Color,
    dataPoints: List<Pair<Long, Float>>,
    minFixed: Float? = null,
    maxFixed: Float? = null,
    modifier: Modifier = Modifier,
    testTag: String = "telemetry_line_graph"
) {
    val timeFormatter = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }
    val latestValue = dataPoints.lastOrNull()?.second

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag(testTag),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )

            if (latestValue != null) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = accentColor.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(alpha = 0.4f))
                ) {
                    Text(
                        text = "Current: $latestValue$unit",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = accentColor
                    )
                }
            }
        }

        if (dataPoints.isEmpty()) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp),
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "Menunggu data telemetry terkumpul...",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            // Render Graph Canvas
            val minVal = minFixed ?: (dataPoints.minOfOrNull { it.second } ?: 0f)
            val maxVal = maxFixed ?: ((dataPoints.maxOfOrNull { it.second } ?: 100f).coerceAtLeast(minVal + 1f))
            val valueRange = (maxVal - minVal).coerceAtLeast(1f)

            val minTime = dataPoints.first().first
            val maxTime = dataPoints.last().first
            val timeRange = (maxTime - minTime).coerceAtLeast(1000L)

            val gridColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.25f)
            val onSurfaceColor = MaterialTheme.colorScheme.onSurfaceVariant

            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp),
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))
            ) {
                Box(modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 12.dp)) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val width = size.width
                        val height = size.height

                        // Draw Horizontal Grid Lines
                        val gridLines = 3
                        for (i in 0..gridLines) {
                            val y = height * (i.toFloat() / gridLines)
                            drawLine(
                                color = gridColor,
                                start = Offset(0f, y),
                                end = Offset(width, y),
                                strokeWidth = 1.dp.toPx()
                            )
                        }

                        // Calculate Coordinates
                        val points = dataPoints.map { (timestamp, value) ->
                            val xFraction = if (timeRange > 0) {
                                (timestamp - minTime).toFloat() / timeRange
                            } else 1f
                            val yFraction = 1f - ((value - minVal) / valueRange).coerceIn(0f, 1f)

                            Offset(
                                x = xFraction * width,
                                y = yFraction * (height - 16f) + 8f
                            )
                        }

                        if (points.size >= 2) {
                            val linePath = Path()
                            val fillPath = Path()

                            linePath.moveTo(points.first().x, points.first().y)
                            fillPath.moveTo(points.first().x, height)
                            fillPath.lineTo(points.first().x, points.first().y)

                            for (i in 1 until points.size) {
                                val prev = points[i - 1]
                                val curr = points[i]
                                val midX = (prev.x + curr.x) / 2f
                                linePath.cubicTo(midX, prev.y, midX, curr.y, curr.x, curr.y)
                                fillPath.cubicTo(midX, prev.y, midX, curr.y, curr.x, curr.y)
                            }

                            fillPath.lineTo(points.last().x, height)
                            fillPath.close()

                            // Draw Gradient Fill
                            drawPath(
                                path = fillPath,
                                brush = Brush.verticalGradient(
                                    colors = listOf(
                                        accentColor.copy(alpha = 0.35f),
                                        accentColor.copy(alpha = 0.02f)
                                    ),
                                    startY = 0f,
                                    endY = height
                                )
                            )

                            // Draw Main Line
                            drawPath(
                                path = linePath,
                                color = accentColor,
                                style = Stroke(
                                    width = 2.5.dp.toPx(),
                                    cap = StrokeCap.Round,
                                    join = StrokeJoin.Round
                                )
                            )

                            // Draw Last Point Dot
                            val lastPoint = points.last()
                            drawCircle(
                                color = accentColor,
                                radius = 4.5.dp.toPx(),
                                center = lastPoint
                            )
                            drawCircle(
                                color = Color.White,
                                radius = 2.dp.toPx(),
                                center = lastPoint
                            )
                        } else if (points.size == 1) {
                            val pt = points.first()
                            drawCircle(
                                color = accentColor,
                                radius = 5.dp.toPx(),
                                center = pt
                            )
                        }
                    }

                    // Top/Bottom Value Labels
                    Row(
                        modifier = Modifier.fillMaxSize(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Max: ${maxVal.toInt()}$unit",
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 9.sp,
                                color = onSurfaceColor.copy(alpha = 0.7f),
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Min: ${minVal.toInt()}$unit",
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 9.sp,
                                color = onSurfaceColor.copy(alpha = 0.7f),
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        // Time Axis Markers
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            horizontalAlignment = Alignment.End,
                            verticalArrangement = Arrangement.Bottom
                        ) {
                            Text(
                                text = "${timeFormatter.format(Date(minTime))} - ${timeFormatter.format(Date(maxTime))}",
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 9.sp,
                                color = onSurfaceColor.copy(alpha = 0.7f),
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}
