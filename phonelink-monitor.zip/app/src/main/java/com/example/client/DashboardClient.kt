package com.example.client

import android.util.Log
import com.example.model.BatteryInfo
import com.example.model.DeviceStatus
import com.example.model.ThermalInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

enum class ConnectionStatus {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    RECONNECTING
}

data class DashboardState(
    val connectionStatus: ConnectionStatus = ConnectionStatus.DISCONNECTED,
    val targetIp: String = "192.168.43.1",
    val port: String = "8080",
    val autoReconnect: Boolean = true,
    val isConnecting: Boolean = false,
    val rawResponse: String? = null,
    val deviceStatus: DeviceStatus? = null,
    val latencyMs: Long? = null,
    val lastSuccessTime: Long? = null,
    val failedAttempts: Int = 0,
    val nextRetryDelaySec: Int = 0,
    val errorMessage: String? = null
)

class DashboardClient(
    private val scope: CoroutineScope
) {
    private val TAG = "DashboardClient"

    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(2000, TimeUnit.MILLISECONDS)
        .readTimeout(2000, TimeUnit.MILLISECONDS)
        .writeTimeout(2000, TimeUnit.MILLISECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val _state = MutableStateFlow(DashboardState())
    val state: StateFlow<DashboardState> = _state.asStateFlow()

    private var pollingJob: Job? = null
    var onDataReceived: ((DeviceStatus) -> Unit)? = null

    // Exponential Backoff constants
    private val BASE_POLL_INTERVAL_MS = 1500L
    private val INITIAL_RETRY_DELAY_MS = 1500L
    private val MAX_RETRY_DELAY_MS = 15000L
    private var currentRetryDelayMs = INITIAL_RETRY_DELAY_MS

    fun updateTargetIp(ip: String) {
        _state.update { it.copy(targetIp = ip.trim()) }
    }

    fun updatePort(port: String) {
        _state.update { it.copy(port = port.trim()) }
    }

    fun toggleAutoReconnect(enabled: Boolean) {
        _state.update { it.copy(autoReconnect = enabled) }
    }

    fun connect() {
        val currentIp = _state.value.targetIp.trim()
        val currentPort = _state.value.port.trim().toIntOrNull() ?: 8080

        if (currentIp.isEmpty()) {
            _state.update { it.copy(errorMessage = "Masukkan IP address HP 1 terlebih dahulu") }
            return
        }

        stopPolling()
        currentRetryDelayMs = INITIAL_RETRY_DELAY_MS

        _state.update {
            it.copy(
                connectionStatus = ConnectionStatus.CONNECTING,
                isConnecting = true,
                errorMessage = null,
                failedAttempts = 0,
                nextRetryDelaySec = 0
            )
        }

        startPolling(currentIp, currentPort)
    }

    fun disconnect() {
        stopPolling()
        currentRetryDelayMs = INITIAL_RETRY_DELAY_MS
        _state.update {
            it.copy(
                connectionStatus = ConnectionStatus.DISCONNECTED,
                isConnecting = false,
                errorMessage = null,
                nextRetryDelaySec = 0
            )
        }
    }

    private fun stopPolling() {
        pollingJob?.cancel()
        pollingJob = null
    }

    private fun startPolling(ip: String, port: Int) {
        pollingJob = scope.launch(Dispatchers.IO) {
            val url = "http://$ip:$port/api/status"
            Log.d(TAG, "Starting poll loop to: $url")

            while (isActive) {
                val startTime = System.currentTimeMillis()
                var requestSucceeded = false

                try {
                    val request = Request.Builder()
                        .url(url)
                        .header("Accept", "application/json")
                        .build()

                    val response = httpClient.newCall(request).execute()
                    val latency = System.currentTimeMillis() - startTime
                    val responseBody = response.body?.string() ?: ""

                    if (response.isSuccessful) {
                        requestSucceeded = true
                        val json = JSONObject(responseBody)

                        // 1. Device name parsing
                        val deviceName = if (json.has("device") && json.optJSONObject("device") != null) {
                            json.getJSONObject("device").optString("name", "Phone 1")
                        } else {
                            json.optString("device", "Phone 1")
                        }

                        val status = json.optString("status", "online")
                        val timestamp = json.optLong("timestamp", System.currentTimeMillis())

                        // 2. Battery telemetry parsing
                        val batteryObj = json.optJSONObject("battery")
                        val batteryInfo = if (batteryObj != null) {
                            BatteryInfo(
                                level = batteryObj.optIntOrNull("level"),
                                temperature = batteryObj.optDoubleOrNull("temperature")?.toFloat(),
                                voltage = batteryObj.optDoubleOrNull("voltage")?.toFloat(),
                                current = batteryObj.optIntOrNull("current"),
                                power = batteryObj.optDoubleOrNull("power")?.toFloat(),
                                charging = batteryObj.optBooleanOrNull("charging"),
                                health = batteryObj.optStringOrNull("health")
                            )
                        } else null

                        // 3. Thermal telemetry parsing
                        val thermalObj = json.optJSONObject("thermal")
                        val thermalInfo = if (thermalObj != null) {
                            ThermalInfo(
                                batteryTemperature = thermalObj.optDoubleOrNull("batteryTemperature")?.toFloat(),
                                cpuTemperature = thermalObj.optDoubleOrNull("cpuTemperature")?.toFloat(),
                                gpuTemperature = thermalObj.optDoubleOrNull("gpuTemperature")?.toFloat(),
                                thermalStatus = thermalObj.optStringOrNull("thermalStatus")
                            )
                        } else null

                        val parsedStatus = DeviceStatus(
                            device = deviceName,
                            status = status,
                            timestamp = timestamp,
                            battery = batteryInfo,
                            thermal = thermalInfo
                        )

                        // Reset exponential backoff on successful connection
                        currentRetryDelayMs = INITIAL_RETRY_DELAY_MS

                        _state.update {
                            it.copy(
                                connectionStatus = ConnectionStatus.CONNECTED,
                                isConnecting = false,
                                rawResponse = responseBody,
                                deviceStatus = parsedStatus,
                                latencyMs = latency,
                                lastSuccessTime = System.currentTimeMillis(),
                                failedAttempts = 0,
                                nextRetryDelaySec = 0,
                                errorMessage = null
                            )
                        }

                        try {
                            onDataReceived?.invoke(parsedStatus)
                        } catch (e: Throwable) {
                            Log.e(TAG, "Error in onDataReceived callback: ${e.message}")
                        }
                    } else {
                        handleFetchFailure("HTTP ${response.code}: ${response.message}")
                    }
                } catch (e: Exception) {
                    val errorMsg = e.localizedMessage ?: e.message ?: "Koneksi gagal"
                    handleFetchFailure(errorMsg)
                }

                if (!_state.value.autoReconnect && _state.value.connectionStatus == ConnectionStatus.DISCONNECTED) {
                    break
                }

                // Determine delay before next poll/retry attempt
                val delayTime = if (requestSucceeded) {
                    BASE_POLL_INTERVAL_MS
                } else {
                    val retryDelay = currentRetryDelayMs
                    // Exponential backoff with ceiling (1.5s -> 3s -> 6s -> 12s -> 15s)
                    currentRetryDelayMs = minOf(currentRetryDelayMs * 2, MAX_RETRY_DELAY_MS)
                    retryDelay
                }

                _state.update { it.copy(nextRetryDelaySec = (delayTime / 1000).toInt()) }
                delay(delayTime)
            }
        }
    }

    private fun handleFetchFailure(errorMsg: String) {
        val friendlyMessage = formatFriendlyError(errorMsg, _state.value.targetIp, _state.value.port)
        Log.w(TAG, "Fetch failure: $errorMsg -> $friendlyMessage, next backoff: ${currentRetryDelayMs}ms")
        _state.update {
            val newFailedCount = it.failedAttempts + 1
            val newStatus = if (it.autoReconnect) {
                ConnectionStatus.RECONNECTING
            } else {
                ConnectionStatus.DISCONNECTED
            }
            it.copy(
                connectionStatus = newStatus,
                isConnecting = false,
                failedAttempts = newFailedCount,
                errorMessage = "$friendlyMessage (Percobaan $newFailedCount)"
            )
        }
    }

    private fun formatFriendlyError(rawError: String, targetIp: String, port: String): String {
        val lower = rawError.lowercase()
        return when {
            lower.contains("refused") -> "Server is not running on port $port. Pastikan Monitor Server di HP 1 ($targetIp) sudah AKTIF."
            lower.contains("timeout") || lower.contains("timed out") -> "Phone 1 ($targetIp) is unreachable. Check that both phones are connected to the same Wi-Fi/hotspot."
            lower.contains("unreachable") || lower.contains("no route") -> "Phone 1 is unreachable. Pastikan kedua HP terhubung ke Wi-Fi / Hotspot yang sama."
            lower.contains("unknown host") || lower.contains("invalid") -> "Format IP address ($targetIp) tidak valid. Periksa kembali IP di HP 1."
            lower.contains("404") -> "Endpoint telemetri tidak ditemukan di HP 1."
            lower.contains("500") || lower.contains("502") || lower.contains("503") -> "Server HP 1 sedang sibuk atau mengalami kendala internal."
            else -> "Phone 1 is unreachable. Check that both phones are connected to the same Wi-Fi/hotspot."
        }
    }

    private fun JSONObject.optIntOrNull(key: String): Int? {
        if (!has(key) || isNull(key)) return null
        return try { getInt(key) } catch (e: Exception) { null }
    }

    private fun JSONObject.optDoubleOrNull(key: String): Double? {
        if (!has(key) || isNull(key)) return null
        return try { getDouble(key) } catch (e: Exception) { null }
    }

    private fun JSONObject.optBooleanOrNull(key: String): Boolean? {
        if (!has(key) || isNull(key)) return null
        return try { getBoolean(key) } catch (e: Exception) { null }
    }

    private fun JSONObject.optStringOrNull(key: String): String? {
        if (!has(key) || isNull(key)) return null
        val str = optString(key)
        return if (str == "null" || str.isEmpty()) null else str
    }
}
