package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.alerts.AlertSettings
import com.example.alerts.AlertType
import com.example.alerts.SmartAlertManager
import com.example.client.ConnectionStatus
import com.example.client.DashboardClient
import com.example.db.AppDatabase
import com.example.db.TelemetryDao
import com.example.db.TelemetryLogEntity
import com.example.model.BatteryInfo
import com.example.model.DeviceStatus
import com.example.model.ThermalInfo
import com.example.server.MonitorHttpServer
import com.example.server.MonitorService
import com.example.utils.NetworkUtils
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class PhoneLinkUnitTest {

    private lateinit var db: AppDatabase
    private lateinit var dao: TelemetryDao

    @Before
    fun createDb() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        dao = db.telemetryDao()
    }

    @After
    fun closeDb() {
        db.close()
    }

    @Test
    fun testDeviceStatusModel() {
        val now = System.currentTimeMillis()
        val status = DeviceStatus(
            device = "Phone 1",
            status = "online",
            timestamp = now,
            battery = BatteryInfo(
                level = 18,
                temperature = 46.5f,
                voltage = 3.9f,
                current = 450,
                power = 1.75f,
                charging = false,
                health = "GOOD"
            ),
            thermal = ThermalInfo(
                batteryTemperature = 46.5f,
                cpuTemperature = 48.0f,
                gpuTemperature = null,
                thermalStatus = "MODERATE"
            )
        )

        assertEquals("Phone 1", status.device)
        assertEquals("online", status.status)
        assertEquals(now, status.timestamp)
        assertEquals(18, status.battery?.level)
        assertEquals(46.5f, status.battery?.temperature)
    }

    @Test
    fun testJsonResponseParsing() {
        val jsonString = """
            {
              "device": "Phone 1",
              "status": "online",
              "timestamp": 123456789,
              "battery": {
                "level": 15,
                "temperature": 47.0,
                "charging": false
              }
            }
        """.trimIndent()

        val json = JSONObject(jsonString)
        assertEquals("Phone 1", json.getString("device"))
        assertEquals("online", json.getString("status"))
        assertEquals(123456789L, json.getLong("timestamp"))
        val battery = json.getJSONObject("battery")
        assertEquals(15, battery.getInt("level"))
        assertEquals(47.0, battery.getDouble("temperature"), 0.01)
    }

    @Test
    fun testSmartAlertEvaluation_LowBatteryAndHighTemp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val alertManager = SmartAlertManager(context)

        alertManager.updateSettings(
            AlertSettings(
                lowBatteryThreshold = 20,
                highTempThreshold = 45.0f,
                notificationsEnabled = true,
                cooldownMinutes = 3
            )
        )

        // Status with 15% battery (<= 20) and 48.0°C (>= 45)
        val status = DeviceStatus(
            device = "Phone 1",
            status = "online",
            timestamp = System.currentTimeMillis(),
            battery = BatteryInfo(
                level = 15,
                temperature = 48.0f,
                charging = false
            )
        )

        alertManager.evaluateStatus(status)
        val activeAlerts = alertManager.activeAlerts.value

        assertEquals(2, activeAlerts.size)
        assertTrue(activeAlerts.any { it.type == AlertType.LOW_BATTERY })
        assertTrue(activeAlerts.any { it.type == AlertType.HIGH_TEMPERATURE })

        val lowBatteryAlert = activeAlerts.first { it.type == AlertType.LOW_BATTERY }
        assertEquals("LOW BATTERY", lowBatteryAlert.title)
        assertEquals("Phone 1 battery is low.", lowBatteryAlert.message)

        val highTempAlert = activeAlerts.first { it.type == AlertType.HIGH_TEMPERATURE }
        assertEquals("HIGH TEMPERATURE", highTempAlert.title)
        assertEquals("Phone 1 temperature is high.", highTempAlert.message)
    }

    @Test
    fun testRoomDatabaseHistoryLogs() = runBlocking {
        val now = System.currentTimeMillis()
        val log1 = TelemetryLogEntity(
            timestamp = now - 30000,
            deviceName = "Phone 1",
            batteryLevel = 80,
            batteryTemperature = 35.5f,
            voltage = 4.1f,
            current = 200,
            power = 0.8f,
            charging = true,
            health = "GOOD",
            thermalStatus = "NORMAL",
            cpuTemperature = 36.0f,
            gpuTemperature = null
        )
        val log2 = TelemetryLogEntity(
            timestamp = now - 10000,
            deviceName = "Phone 1",
            batteryLevel = 81,
            batteryTemperature = 36.0f,
            voltage = 4.15f,
            current = 220,
            power = 0.9f,
            charging = true,
            health = "GOOD",
            thermalStatus = "NORMAL",
            cpuTemperature = 36.5f,
            gpuTemperature = null
        )

        dao.insertLog(log1)
        dao.insertLog(log2)

        val logs = dao.getLogsSince(now - 60000).first()
        assertEquals(2, logs.size)
        assertEquals(80, logs[0].batteryLevel)
        assertEquals(81, logs[1].batteryLevel)
    }

    @Test
    fun testNetworkUtilsFallback() {
        val ips = NetworkUtils.getLocalIpAddresses()
        assertNotNull(ips)
        assertTrue(ips.isNotEmpty())
    }

    @Test
    fun testMonitorHttpServerLifecycle() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val server = MonitorHttpServer(context)

        server.refreshNetworkInfo()
        val state = server.state.value
        assertNotNull(state)
        assertFalse(state.isRunning)
        assertEquals(8080, state.port)
        assertTrue(state.localIps.isNotEmpty())
    }

    @Test
    fun testDashboardClientState() {
        val testDispatcher = UnconfinedTestDispatcher()
        val testScope = TestScope(testDispatcher)
        val client = DashboardClient(testScope)

        assertEquals(ConnectionStatus.DISCONNECTED, client.state.value.connectionStatus)
        assertEquals("192.168.43.1", client.state.value.targetIp)
        assertEquals("8080", client.state.value.port)

        client.updateTargetIp("10.0.0.5")
        client.updatePort("8888")
        assertEquals("10.0.0.5", client.state.value.targetIp)
        assertEquals("8888", client.state.value.port)
    }
}
