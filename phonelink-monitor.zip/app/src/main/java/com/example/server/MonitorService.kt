package com.example.server

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.utils.NetworkUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class MonitorService : Service() {

    private val TAG = "MonitorService"
    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.Main + serviceJob)

    private lateinit var notificationManager: NotificationManager
    private var connectivityManager: ConnectivityManager? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    override fun onCreate() {
        super.onCreate()
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        createNotificationChannel()
        registerNetworkCallback()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START

        when (action) {
            ACTION_STOP -> {
                Log.d(TAG, "Stopping MonitorService")
                stopServerInstance()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                val port = intent?.getIntExtra(EXTRA_PORT, 8080) ?: 8080
                Log.d(TAG, "Starting MonitorService on port $port")

                val notification = buildServerNotification(port)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val serviceType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE or ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                    } else {
                        0
                    }
                    startForeground(NOTIFICATION_ID, notification, serviceType)
                } else {
                    startForeground(NOTIFICATION_ID, notification)
                }

                startServerInstance(port)
                return START_STICKY
            }
            else -> {
                return START_NOT_STICKY
            }
        }
    }

    private fun startServerInstance(port: Int) {
        val server = getServer(applicationContext)
        server.start(port)

        // Observe server state changes to refresh notification if needed
        serviceScope.launch {
            server.state.collect { state ->
                if (state.isRunning) {
                    val updatedNotification = buildServerNotification(state.port, state.localIps)
                    notificationManager.notify(NOTIFICATION_ID, updatedNotification)
                }
            }
        }
    }

    private fun stopServerInstance() {
        val server = getServer(applicationContext)
        server.stop()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "PhoneLink Server Status",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notifikasi status background server pemantau PhoneLink (HP 1)"
                setShowBadge(false)
                enableVibration(false)
                enableLights(false)
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun buildServerNotification(port: Int, ips: List<String> = emptyList()): Notification {
        // PendingIntent to launch MainActivity when clicking notification
        val contentIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingContentIntent = PendingIntent.getActivity(
            this,
            0,
            contentIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // PendingIntent to stop server directly from notification action
        val stopIntent = Intent(this, MonitorService::class.java).apply {
            action = ACTION_STOP
        }
        val pendingStopIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val primaryIp = if (ips.isNotEmpty()) ips.first() else NetworkUtils.getLocalIpAddresses().firstOrNull() ?: "192.168.43.1"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("PhoneLink Monitor")
            .setContentText("Monitoring server is running")
            .setSubText("Port: $port")
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("Monitoring server is running\nIP: http://$primaryIp:$port/api/status\nLayar dapat dimatikan dengan aman.")
            )
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingContentIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                "STOP SERVER",
                pendingStopIntent
            )
            .build()
    }

    private fun registerNetworkCallback() {
        try {
            connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val builder = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)

            networkCallback = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    Log.d(TAG, "Network available, refreshing local IP addresses")
                    val server = getServer(applicationContext)
                    server.refreshNetworkInfo()
                }

                override fun onLost(network: Network) {
                    Log.d(TAG, "Network lost, refreshing local IP addresses")
                    val server = getServer(applicationContext)
                    server.refreshNetworkInfo()
                }

                override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                    val server = getServer(applicationContext)
                    server.refreshNetworkInfo()
                }
            }

            connectivityManager?.registerNetworkCallback(builder.build(), networkCallback!!)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to register NetworkCallback: ${e.message}")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            if (networkCallback != null && connectivityManager != null) {
                connectivityManager?.unregisterNetworkCallback(networkCallback!!)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error unregistering network callback: ${e.message}")
        }
        stopServerInstance()
        serviceScope.cancel()
        Log.d(TAG, "MonitorService destroyed")
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.example.phonelink.ACTION_START_SERVER"
        const val ACTION_STOP = "com.example.phonelink.ACTION_STOP_SERVER"
        const val EXTRA_PORT = "extra_port"
        const val CHANNEL_ID = "phonelink_monitor_server_channel"
        const val NOTIFICATION_ID = 2001

        @Volatile
        private var serverInstance: MonitorHttpServer? = null

        fun getServer(context: Context): MonitorHttpServer {
            return serverInstance ?: synchronized(this) {
                serverInstance ?: MonitorHttpServer(context.applicationContext).also {
                    serverInstance = it
                }
            }
        }

        fun start(context: Context, port: Int = 8080) {
            val intent = Intent(context, MonitorService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_PORT, port)
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    ContextCompat.startForegroundService(context, intent)
                } else {
                    context.startService(intent)
                }
            } catch (e: Exception) {
                Log.e("MonitorService", "Failed to start foreground service: ${e.message}", e)
                // Fallback to in-process server if background service start restriction triggers
                getServer(context).start(port)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, MonitorService::class.java).apply {
                action = ACTION_STOP
            }
            try {
                context.startService(intent)
            } catch (e: Exception) {
                Log.e("MonitorService", "Failed to stop service via intent: ${e.message}", e)
                getServer(context).stop()
            }
        }
    }
}
