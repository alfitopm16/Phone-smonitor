package com.example.alerts

import android.content.Context
import android.content.SharedPreferences

data class AlertSettings(
    val lowBatteryThreshold: Int = 20,         // Default: 20%
    val highTempThreshold: Float = 45.0f,      // Default: 45.0°C
    val notificationsEnabled: Boolean = true,  // Default: enabled
    val cooldownMinutes: Int = 3               // Default: 3 minutes cooldown
)

class AlertSettingsManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("phonelink_alert_settings", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_LOW_BATTERY_THRESHOLD = "low_battery_threshold"
        private const val KEY_HIGH_TEMP_THRESHOLD = "high_temp_threshold"
        private const val KEY_NOTIFICATIONS_ENABLED = "notifications_enabled"
        private const val KEY_COOLDOWN_MINUTES = "cooldown_minutes"
    }

    fun loadSettings(): AlertSettings {
        return AlertSettings(
            lowBatteryThreshold = prefs.getInt(KEY_LOW_BATTERY_THRESHOLD, 20),
            highTempThreshold = prefs.getFloat(KEY_HIGH_TEMP_THRESHOLD, 45.0f),
            notificationsEnabled = prefs.getBoolean(KEY_NOTIFICATIONS_ENABLED, true),
            cooldownMinutes = prefs.getInt(KEY_COOLDOWN_MINUTES, 3)
        )
    }

    fun saveSettings(settings: AlertSettings) {
        prefs.edit()
            .putInt(KEY_LOW_BATTERY_THRESHOLD, settings.lowBatteryThreshold)
            .putFloat(KEY_HIGH_TEMP_THRESHOLD, settings.highTempThreshold)
            .putBoolean(KEY_NOTIFICATIONS_ENABLED, settings.notificationsEnabled)
            .putInt(KEY_COOLDOWN_MINUTES, settings.cooldownMinutes)
            .apply()
    }
}
