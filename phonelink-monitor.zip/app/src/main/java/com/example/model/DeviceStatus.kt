package com.example.model

data class BatteryInfo(
    val level: Int? = null,
    val temperature: Float? = null,
    val voltage: Float? = null,
    val current: Int? = null,
    val power: Float? = null,
    val charging: Boolean? = null,
    val health: String? = null
)

data class ThermalInfo(
    val batteryTemperature: Float? = null,
    val cpuTemperature: Float? = null,
    val gpuTemperature: Float? = null,
    val thermalStatus: String? = null
)

data class DeviceStatus(
    val device: String,
    val status: String,
    val timestamp: Long = System.currentTimeMillis(),
    val battery: BatteryInfo? = null,
    val thermal: ThermalInfo? = null
)
