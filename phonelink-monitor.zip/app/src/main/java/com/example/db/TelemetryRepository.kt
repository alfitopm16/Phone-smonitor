package com.example.db

import com.example.model.DeviceStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

enum class HistoryTimeRange(val label: String, val durationMillis: Long) {
    ONE_MINUTE("1 min", 60 * 1000L),
    FIVE_MINUTES("5 min", 5 * 60 * 1000L),
    FIFTEEN_MINUTES("15 min", 15 * 60 * 1000L),
    ONE_HOUR("1 hour", 60 * 60 * 1000L)
}

class TelemetryRepository(private val dao: TelemetryDao) {

    suspend fun saveDeviceStatus(status: DeviceStatus) = withContext(Dispatchers.IO) {
        val entity = TelemetryLogEntity(
            timestamp = status.timestamp,
            deviceName = status.device,
            batteryLevel = status.battery?.level,
            batteryTemperature = status.battery?.temperature,
            voltage = status.battery?.voltage,
            current = status.battery?.current,
            power = status.battery?.power,
            charging = status.battery?.charging,
            health = status.battery?.health,
            thermalStatus = status.thermal?.thermalStatus,
            cpuTemperature = status.thermal?.cpuTemperature,
            gpuTemperature = status.thermal?.gpuTemperature
        )
        dao.insertLog(entity)

        // Prune entries older than 24 hours to prevent unbounded DB growth
        val oneDayAgo = System.currentTimeMillis() - (24 * 60 * 60 * 1000L)
        dao.deleteOlderThan(oneDayAgo)
    }

    fun getLogsForRange(range: HistoryTimeRange): Flow<List<TelemetryLogEntity>> {
        val since = System.currentTimeMillis() - range.durationMillis
        return dao.getLogsSince(since)
    }

    fun getLogsSince(sinceTimestamp: Long): Flow<List<TelemetryLogEntity>> {
        return dao.getLogsSince(sinceTimestamp)
    }

    suspend fun clearHistory() = withContext(Dispatchers.IO) {
        dao.clearAll()
    }
}
