package com.example.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "telemetry_logs",
    indices = [Index(value = ["timestamp"])]
)
data class TelemetryLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val deviceName: String = "Phone 1",
    val batteryLevel: Int? = null,
    val batteryTemperature: Float? = null,
    val voltage: Float? = null,
    val current: Int? = null,
    val power: Float? = null,
    val charging: Boolean? = null,
    val health: String? = null,
    val thermalStatus: String? = null,
    val cpuTemperature: Float? = null,
    val gpuTemperature: Float? = null
)
