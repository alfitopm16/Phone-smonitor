package com.example.telemetry

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.util.Log
import com.example.model.BatteryInfo
import com.example.model.DeviceStatus
import com.example.model.ThermalInfo
import org.json.JSONObject
import java.io.File
import java.util.Locale
import kotlin.math.abs

class HardwareTelemetryProvider(
    private val context: Context
) {
    private val TAG = "HardwareTelemetry"

    fun getBatteryInfo(): BatteryInfo {
        try {
            val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val batteryIntent = try {
                context.registerReceiver(null, filter)
            } catch (e: Throwable) {
                null
            }

            // 1. Battery Percentage Level
            val rawLevel = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val level: Int? = if (rawLevel >= 0 && scale > 0) {
                (rawLevel * 100) / scale
            } else null

            // 2. Battery Temperature (tenths of a degree Celsius -> Celsius)
            val rawTemp = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
            val temperature: Float? = if (rawTemp > 0) {
                String.format(Locale.US, "%.1f", rawTemp / 10.0f).toFloatOrNull()
            } else null

            // 3. Battery Voltage (mV -> V)
            val rawVoltage = batteryIntent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1) ?: -1
            val voltage: Float? = if (rawVoltage > 0) {
                val inVolts = if (rawVoltage > 100) rawVoltage / 1000.0f else rawVoltage.toFloat()
                String.format(Locale.US, "%.2f", inVolts).toFloatOrNull()
            } else null

            // 4. Charging Status
            val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val charging: Boolean? = if (status != -1) {
                status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
            } else null

            // 5. Battery Health
            val healthCode = batteryIntent?.getIntExtra(BatteryManager.EXTRA_HEALTH, -1) ?: -1
            val health: String? = when (healthCode) {
                BatteryManager.BATTERY_HEALTH_GOOD -> "GOOD"
                BatteryManager.BATTERY_HEALTH_OVERHEAT -> "OVERHEAT"
                BatteryManager.BATTERY_HEALTH_DEAD -> "DEAD"
                BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "OVER_VOLTAGE"
                BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "UNSPECIFIED_FAILURE"
                BatteryManager.BATTERY_HEALTH_COLD -> "COLD"
                BatteryManager.BATTERY_HEALTH_UNKNOWN -> "UNKNOWN"
                else -> null
            }

            // 6. Battery Current (mA) from BatteryManager system service
            val currentMa: Int? = try {
                val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
                val rawCurrent = batteryManager?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
                if (rawCurrent != null && rawCurrent != Int.MIN_VALUE && rawCurrent != 0) {
                    // Android docs state BATTERY_PROPERTY_CURRENT_NOW is microamperes (µA) on most devices
                    val converted = if (abs(rawCurrent) >= 10000) rawCurrent / 1000 else rawCurrent
                    abs(converted)
                } else null
            } catch (e: Throwable) {
                null
            }

            // 7. Battery Power (W) = Voltage (V) * Current (mA) / 1000.0
            val power: Float? = if (voltage != null && currentMa != null) {
                val watts = (voltage * currentMa) / 1000.0f
                String.format(Locale.US, "%.2f", watts).toFloatOrNull()
            } else null

            return BatteryInfo(
                level = level,
                temperature = temperature,
                voltage = voltage,
                current = currentMa,
                power = power,
                charging = charging,
                health = health
            )
        } catch (e: Throwable) {
            Log.w(TAG, "Error querying battery info: ${e.message}")
            return BatteryInfo(null, null, null, null, null, null, null)
        }
    }

    fun getThermalInfo(batteryTemp: Float?): ThermalInfo {
        try {
            // 1. CPU Temperature (checked via sysfs if accessible by OS/permissions)
            val cpuTemp = readSysfsCpuTemp()

            // 2. GPU Temperature (standard Android does not expose non-root GPU sysfs)
            val gpuTemp = readSysfsGpuTemp()

            // 3. Android Thermal Status (API 29+)
            val thermalStatus = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                try {
                    val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
                    when (powerManager?.currentThermalStatus) {
                        PowerManager.THERMAL_STATUS_NONE -> "NORMAL"
                        PowerManager.THERMAL_STATUS_LIGHT -> "LIGHT"
                        PowerManager.THERMAL_STATUS_MODERATE -> "MODERATE"
                        PowerManager.THERMAL_STATUS_SEVERE -> "SEVERE"
                        PowerManager.THERMAL_STATUS_CRITICAL -> "CRITICAL"
                        PowerManager.THERMAL_STATUS_EMERGENCY -> "EMERGENCY"
                        PowerManager.THERMAL_STATUS_SHUTDOWN -> "SHUTDOWN"
                        else -> "NORMAL"
                    }
                } catch (e: Throwable) {
                    "NORMAL"
                }
            } else {
                "N/A"
            }

            return ThermalInfo(
                batteryTemperature = batteryTemp,
                cpuTemperature = cpuTemp,
                gpuTemperature = gpuTemp,
                thermalStatus = thermalStatus
            )
        } catch (e: Throwable) {
            Log.w(TAG, "Error querying thermal info: ${e.message}")
            return ThermalInfo(batteryTemperature = batteryTemp, cpuTemperature = null, gpuTemperature = null, thermalStatus = "N/A")
        }
    }

    fun getCurrentDeviceStatus(): DeviceStatus {
        try {
            val batteryInfo = getBatteryInfo()
            val thermalInfo = getThermalInfo(batteryInfo.temperature)

            return DeviceStatus(
                device = "Phone 1",
                status = "online",
                timestamp = System.currentTimeMillis(),
                battery = batteryInfo,
                thermal = thermalInfo
            )
        } catch (e: Throwable) {
            return DeviceStatus(
                device = "Phone 1",
                status = "online",
                timestamp = System.currentTimeMillis(),
                battery = null,
                thermal = null
            )
        }
    }

    fun buildStatusJsonResponse(): String {
        val status = getCurrentDeviceStatus()
        val json = JSONObject()

        // Device name object
        val deviceObj = JSONObject().apply {
            put("name", status.device)
        }
        json.put("device", deviceObj)
        json.put("status", status.status)
        json.put("timestamp", status.timestamp)

        // Battery telemetry
        val batteryObj = JSONObject().apply {
            putOrNull("level", status.battery?.level)
            putOrNull("temperature", status.battery?.temperature)
            putOrNull("voltage", status.battery?.voltage)
            putOrNull("current", status.battery?.current)
            putOrNull("power", status.battery?.power)
            putOrNull("charging", status.battery?.charging)
            putOrNull("health", status.battery?.health)
        }
        json.put("battery", batteryObj)

        // Thermal telemetry
        val thermalObj = JSONObject().apply {
            putOrNull("batteryTemperature", status.thermal?.batteryTemperature)
            putOrNull("cpuTemperature", status.thermal?.cpuTemperature)
            putOrNull("gpuTemperature", status.thermal?.gpuTemperature)
            putOrNull("thermalStatus", status.thermal?.thermalStatus)
        }
        json.put("thermal", thermalObj)

        return json.toString(2)
    }

    private fun JSONObject.putOrNull(name: String, value: Any?) {
        if (value != null) {
            put(name, value)
        } else {
            put(name, JSONObject.NULL)
        }
    }

    private fun readSysfsCpuTemp(): Float? {
        val potentialCpuPaths = listOf(
            "/sys/class/thermal/thermal_zone0/temp",
            "/sys/class/thermal/thermal_zone1/temp",
            "/sys/devices/system/cpu/cpu0/cpufreq/cpu_temp",
            "/sys/devices/virtual/thermal/thermal_zone0/temp",
            "/sys/class/hwmon/hwmon0/temp1_input"
        )

        for (path in potentialCpuPaths) {
            try {
                val file = File(path)
                if (file.exists() && file.canRead()) {
                    val rawStr = file.readText().trim()
                    val rawVal = rawStr.toDoubleOrNull() ?: continue
                    if (rawVal > 0) {
                        val tempC = if (rawVal > 1000) rawVal / 1000.0 else rawVal
                        if (tempC in 10.0..110.0) {
                            return String.format(Locale.US, "%.1f", tempC).toFloatOrNull()
                        }
                    }
                }
            } catch (e: Exception) {
                // Ignore security / permission denials gracefully
            }
        }
        return null
    }

    private fun readSysfsGpuTemp(): Float? {
        val potentialGpuPaths = listOf(
            "/sys/class/kgsl/kgsl-3d0/gpu_temp",
            "/sys/class/thermal/thermal_zone2/temp"
        )

        for (path in potentialGpuPaths) {
            try {
                val file = File(path)
                if (file.exists() && file.canRead()) {
                    val rawStr = file.readText().trim()
                    val rawVal = rawStr.toDoubleOrNull() ?: continue
                    if (rawVal > 0) {
                        val tempC = if (rawVal > 1000) rawVal / 1000.0 else rawVal
                        if (tempC in 10.0..110.0) {
                            return String.format(Locale.US, "%.1f", tempC).toFloatOrNull()
                        }
                    }
                }
            } catch (e: Exception) {
                // Ignore gracefully
            }
        }
        return null
    }
}
