package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.alerts.ActiveAlert
import com.example.alerts.AlertSettings
import com.example.alerts.SmartAlertManager
import com.example.client.DashboardClient
import com.example.db.AppDatabase
import com.example.db.HistoryTimeRange
import com.example.db.TelemetryLogEntity
import com.example.db.TelemetryRepository
import com.example.server.MonitorHttpServer
import com.example.server.MonitorService
import com.example.server.ServerState
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppMode {
    MODE_SELECTION, // First screen / Choose mode
    MONITOR,        // HP 1 (Monitor This Device)
    DASHBOARD       // HP 2 (View Another Device)
}

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val _currentMode = MutableStateFlow(AppMode.MODE_SELECTION)
    val currentMode: StateFlow<AppMode> = _currentMode.asStateFlow()

    // 1. Core Services (Tahap 1, 2, 5 Foreground Service)
    val monitorServer: MonitorHttpServer = MonitorService.getServer(application.applicationContext)
    val dashboardClient = DashboardClient(viewModelScope)

    val serverState: StateFlow<ServerState> = monitorServer.state
    val dashboardState = dashboardClient.state

    // 2. Room Local Persistence (Tahap 4)
    private val database = AppDatabase.getDatabase(application.applicationContext)
    val telemetryRepository = TelemetryRepository(database.telemetryDao())

    // 3. Smart Alerts (Tahap 4)
    val smartAlertManager = SmartAlertManager(application.applicationContext)
    val activeAlerts: StateFlow<List<ActiveAlert>> = smartAlertManager.activeAlerts
    val alertSettings: StateFlow<AlertSettings> = smartAlertManager.settings

    // 4. History Time Range Filter (Tahap 4)
    private val _selectedTimeRange = MutableStateFlow(HistoryTimeRange.FIVE_MINUTES)
    val selectedTimeRange: StateFlow<HistoryTimeRange> = _selectedTimeRange.asStateFlow()

    val historyLogs: StateFlow<List<TelemetryLogEntity>> = _selectedTimeRange
        .flatMapLatest { range ->
            telemetryRepository.getLogsForRange(range)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    init {
        // Wire incoming realtime data to Room database and SmartAlertManager
        dashboardClient.onDataReceived = { status ->
            viewModelScope.launch {
                telemetryRepository.saveDeviceStatus(status)
                smartAlertManager.evaluateStatus(status)
            }
        }
    }

    fun selectTimeRange(range: HistoryTimeRange) {
        _selectedTimeRange.value = range
    }

    fun updateAlertSettings(settings: AlertSettings) {
        smartAlertManager.updateSettings(settings)
    }

    fun clearAlerts() {
        smartAlertManager.clearAlerts()
    }

    fun selectMode(mode: AppMode) {
        _currentMode.value = mode
        if (mode == AppMode.MONITOR) {
            monitorServer.refreshNetworkInfo()
        }
    }

    fun backToSelection() {
        _currentMode.value = AppMode.MODE_SELECTION
    }

    fun refreshNetworkIps() {
        monitorServer.refreshNetworkInfo()
    }

    fun toggleServer() {
        if (serverState.value.isRunning) {
            MonitorService.stop(getApplication())
        } else {
            MonitorService.start(getApplication(), serverState.value.port)
        }
    }

    fun startServer(port: Int = 8080) {
        MonitorService.start(getApplication(), port)
    }

    fun stopServer() {
        MonitorService.stop(getApplication())
    }

    override fun onCleared() {
        super.onCleared()
        dashboardClient.disconnect()
    }
}
