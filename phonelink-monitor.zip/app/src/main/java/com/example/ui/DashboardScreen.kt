package com.example.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ElectricMeter
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LinkOff
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Power
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.alerts.ActiveAlert
import com.example.alerts.AlertSettings
import com.example.client.ConnectionStatus
import com.example.client.DashboardState
import com.example.db.HistoryTimeRange
import com.example.db.TelemetryLogEntity
import com.example.model.BatteryInfo
import com.example.model.DeviceStatus
import com.example.model.ThermalInfo
import com.example.ui.components.AlertSettingsDialog
import com.example.ui.components.RealtimeChartsSection
import com.example.ui.components.SmartAlertsBannerList
import com.example.ui.theme.StatusOffline
import com.example.ui.theme.StatusOnline
import com.example.ui.theme.StatusWarning
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DashboardScreen(
    state: DashboardState,
    historyLogs: List<TelemetryLogEntity>,
    selectedTimeRange: HistoryTimeRange,
    onTimeRangeSelected: (HistoryTimeRange) -> Unit,
    activeAlerts: List<ActiveAlert>,
    alertSettings: AlertSettings,
    onSaveAlertSettings: (AlertSettings) -> Unit,
    onIpChange: (String) -> Unit,
    onPortChange: (String) -> Unit,
    onAutoReconnectChange: (Boolean) -> Unit,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val scrollState = rememberScrollState()

    val isConnected = state.connectionStatus == ConnectionStatus.CONNECTED

    // Dialog & UI Visibility states
    var isSettingsExpanded by remember { mutableStateOf(!isConnected) }
    var isRawJsonExpanded by remember { mutableStateOf(false) }
    var showAlertDialog by remember { mutableStateOf(false) }

    // Live dynamic timer for "X seconds ago"
    var currentTime by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            currentTime = System.currentTimeMillis()
            delay(1000L)
        }
    }

    val lastUpdateText = remember(currentTime, state.lastSuccessTime, isConnected) {
        val lastSuccess = state.lastSuccessTime
        if (lastSuccess == null) {
            "Never updated"
        } else {
            val secondsAgo = ((currentTime - lastSuccess) / 1000L).coerceAtLeast(0)
            when {
                secondsAgo < 2 -> "Just now"
                secondsAgo < 60 -> "$secondsAgo seconds ago"
                else -> "${secondsAgo / 60}m ${secondsAgo % 60}s ago"
            }
        }
    }

    // Alert Settings Dialog Modal
    if (showAlertDialog) {
        AlertSettingsDialog(
            settings = alertSettings,
            onDismiss = { showAlertDialog = false },
            onSave = { newSettings ->
                onSaveAlertSettings(newSettings)
                showAlertDialog = false
                Toast.makeText(context, "Pengaturan Alert disimpan", Toast.LENGTH_SHORT).show()
            }
        )
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 640.dp)
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // ==========================================
            // 1. CONNECTION HEADER (PhoneLink Monitor & Live Status)
            // ==========================================
            ConnectionHeaderCard(
                deviceName = state.deviceStatus?.device ?: "Phone 1",
                connectionStatus = state.connectionStatus,
                lastUpdateText = lastUpdateText,
                latencyMs = state.latencyMs,
                onSettingsToggle = { isSettingsExpanded = !isSettingsExpanded },
                isSettingsExpanded = isSettingsExpanded,
                onOpenAlertSettings = { showAlertDialog = true }
            )

            // ==========================================
            // 2. SMART ALERTS BANNER (Tahap 4)
            // ==========================================
            SmartAlertsBannerList(
                activeAlerts = activeAlerts,
                onOpenSettings = { showAlertDialog = true }
            )

            // ==========================================
            // 3. DISCONNECTED / WAITING STATE BANNER
            // ==========================================
            if (!isConnected) {
                DisconnectedStateBanner(
                    status = state.connectionStatus,
                    failedAttempts = state.failedAttempts,
                    nextRetryDelaySec = state.nextRetryDelaySec,
                    lastSuccessTime = state.lastSuccessTime,
                    lastUpdateText = lastUpdateText,
                    errorMessage = state.errorMessage,
                    onConnectClick = {
                        focusManager.clearFocus()
                        onConnect()
                    }
                )
            }

            // ==========================================
            // 4. CONNECTION CONFIGURATION CARD (Collapsible)
            // ==========================================
            AnimatedVisibility(
                visible = isSettingsExpanded || !isConnected,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                ConnectionConfigCard(
                    targetIp = state.targetIp,
                    port = state.port,
                    autoReconnect = state.autoReconnect,
                    connectionStatus = state.connectionStatus,
                    onIpChange = onIpChange,
                    onPortChange = onPortChange,
                    onAutoReconnectChange = onAutoReconnectChange,
                    onConnect = {
                        focusManager.clearFocus()
                        onConnect()
                    },
                    onDisconnect = onDisconnect,
                    onOpenAlertSettings = { showAlertDialog = true }
                )
            }

            // ==========================================
            // 5. BATTERY CARD (Large Prominent Real-Time Gauge)
            // ==========================================
            ModernBatteryCard(
                battery = state.deviceStatus?.battery,
                isLive = isConnected
            )

            // ==========================================
            // 6. TEMPERATURE CARD (Battery, CPU, GPU, Thermal)
            // ==========================================
            ModernTemperatureCard(
                batteryTemp = state.deviceStatus?.battery?.temperature,
                thermal = state.deviceStatus?.thermal,
                isLive = isConnected
            )

            // ==========================================
            // 7. STATUS CARD (Charging, Health, Thermal, Connection)
            // ==========================================
            ModernStatusOverviewCard(
                battery = state.deviceStatus?.battery,
                thermal = state.deviceStatus?.thermal,
                connectionStatus = state.connectionStatus,
                latencyMs = state.latencyMs,
                isLive = isConnected
            )

            // ==========================================
            // 8. REALTIME CHARTS & HISTORY (Tahap 4)
            // ==========================================
            RealtimeChartsSection(
                historyLogs = historyLogs,
                selectedTimeRange = selectedTimeRange,
                onTimeRangeSelected = onTimeRangeSelected
            )

            // ==========================================
            // 9. RAW RESPONSE & METRICS (Collapsible Debug Panel)
            // ==========================================
            RawResponseCard(
                rawResponse = state.rawResponse,
                timestamp = state.deviceStatus?.timestamp,
                isExpanded = isRawJsonExpanded,
                onToggleExpand = { isRawJsonExpanded = !isRawJsonExpanded },
                onCopy = {
                    state.rawResponse?.let {
                        copyToClipboard(context, it, "Response JSON disalin ke clipboard")
                    }
                }
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

// =========================================================================
// SECTION: CONNECTION HEADER
// =========================================================================

@Composable
fun ConnectionHeaderCard(
    deviceName: String,
    connectionStatus: ConnectionStatus,
    lastUpdateText: String,
    latencyMs: Long?,
    onSettingsToggle: () -> Unit,
    isSettingsExpanded: Boolean,
    onOpenAlertSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isConnected = connectionStatus == ConnectionStatus.CONNECTED
    val isConnecting = connectionStatus == ConnectionStatus.CONNECTING || connectionStatus == ConnectionStatus.RECONNECTING

    val infiniteTransition = rememberInfiniteTransition(label = "pulse_header")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.4f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("dashboard_header_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isConnected) MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)
            else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = "PhoneLink Monitor",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = deviceName,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                // Connection Indicator Badge (CONNECTED / RECONNECTING / DISCONNECTED)
                val badgeColor = when (connectionStatus) {
                    ConnectionStatus.CONNECTED -> StatusOnline
                    ConnectionStatus.CONNECTING, ConnectionStatus.RECONNECTING -> StatusWarning
                    ConnectionStatus.DISCONNECTED -> StatusOffline
                }

                val badgeText = when (connectionStatus) {
                    ConnectionStatus.CONNECTED -> "CONNECTED"
                    ConnectionStatus.CONNECTING -> "CONNECTING"
                    ConnectionStatus.RECONNECTING -> "RECONNECTING"
                    ConnectionStatus.DISCONNECTED -> "DISCONNECTED"
                }

                Surface(
                    shape = RoundedCornerShape(100.dp),
                    color = badgeColor.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.2.dp, badgeColor.copy(alpha = 0.5f)),
                    modifier = Modifier.testTag("header_status_badge")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (isConnecting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(10.dp),
                                strokeWidth = 2.dp,
                                color = badgeColor
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(9.dp)
                                    .clip(CircleShape)
                                    .background(badgeColor)
                                    .then(if (isConnected) Modifier.scale(pulseScale) else Modifier)
                            )
                        }
                        Text(
                            text = badgeText,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = badgeColor
                        )
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = if (isConnected) Icons.Default.Sensors else Icons.Default.WifiOff,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = if (isConnected) StatusOnline else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Last update: $lastUpdateText",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.testTag("header_last_update_text")
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (isConnected && latencyMs != null) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ) {
                            Text(
                                text = "${latencyMs}ms",
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    // Alert Settings Button
                    IconButton(
                        onClick = onOpenAlertSettings,
                        modifier = Modifier.size(32.dp).testTag("btn_header_alert_settings")
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = "Pengaturan Alert",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Connection Config Toggle
                    IconButton(
                        onClick = onSettingsToggle,
                        modifier = Modifier.size(32.dp).testTag("btn_toggle_settings")
                    ) {
                        Icon(
                            imageVector = if (isSettingsExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = "Pengaturan Koneksi",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

// =========================================================================
// SECTION: DISCONNECTED STATE BANNER
// =========================================================================

@Composable
fun DisconnectedStateBanner(
    status: ConnectionStatus,
    failedAttempts: Int = 0,
    nextRetryDelaySec: Int = 0,
    lastSuccessTime: Long?,
    lastUpdateText: String,
    errorMessage: String?,
    onConnectClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("disconnected_state_banner"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.25f)
        ),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.error.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (status == ConnectionStatus.RECONNECTING) Icons.Default.Wifi else Icons.Default.WifiOff,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (status == ConnectionStatus.RECONNECTING) "RECONNECTING" else "DISCONNECTED",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.error
                    )
                    Text(
                        text = if (status == ConnectionStatus.RECONNECTING) {
                            if (nextRetryDelaySec > 0) "Mencoba kembali dalam ${nextRetryDelaySec}d (Percobaan #$failedAttempts)..."
                            else "Mencoba reconnect ke HP 1..."
                        } else "Waiting for Phone 1...",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Button(
                    onClick = onConnectClick,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("banner_reconnect_button")
                ) {
                    Text("Hubungkan", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            if (lastSuccessTime != null) {
                val formattedLastTime = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(lastSuccessTime))
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f)
                ) {
                    Text(
                        text = "Waktu terakhir data diterima: $formattedLastTime ($lastUpdateText)",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (errorMessage != null) {
                Text(
                    text = errorMessage,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                    lineHeight = 16.sp
                )
            }
        }
    }
}

// =========================================================================
// SECTION: CONNECTION CONFIGURATION CARD
// =========================================================================

@Composable
fun ConnectionConfigCard(
    targetIp: String,
    port: String,
    autoReconnect: Boolean,
    connectionStatus: ConnectionStatus,
    onIpChange: (String) -> Unit,
    onPortChange: (String) -> Unit,
    onAutoReconnectChange: (Boolean) -> Unit,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit,
    onOpenAlertSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isConnected = connectionStatus == ConnectionStatus.CONNECTED
    val isConnecting = connectionStatus == ConnectionStatus.CONNECTING || connectionStatus == ConnectionStatus.RECONNECTING

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("dashboard_config_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Target Koneksi HP 1",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                TextButton(onClick = onOpenAlertSettings) {
                    Icon(imageVector = Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Alert Settings", fontSize = 12.sp)
                }
            }

            // IP Address Field
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    value = targetIp,
                    onValueChange = onIpChange,
                    label = { Text("IP Address HP 1") },
                    placeholder = { Text("192.168.43.1") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_target_ip"),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(onDone = { onConnect() }),
                    shape = RoundedCornerShape(12.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Shortcut IP:",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    FilterChip(
                        selected = targetIp == "192.168.43.1",
                        onClick = { onIpChange("192.168.43.1") },
                        label = { Text("192.168.43.1 (Hotspot)", fontSize = 11.sp) },
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            }

            // Port Input Field
            OutlinedTextField(
                value = port,
                onValueChange = onPortChange,
                label = { Text("Port HTTP Server (Default: 8080)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_port"),
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Number,
                    imeAction = ImeAction.Done
                ),
                shape = RoundedCornerShape(12.dp)
            )

            // Auto Reconnect Switch
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Auto Reconnect",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Polling otomatis & hubungkan ulang setiap 1.5 detik",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = autoReconnect,
                        onCheckedChange = onAutoReconnectChange,
                        modifier = Modifier.testTag("auto_reconnect_switch")
                    )
                }
            }

            // Action Buttons
            if (!isConnected && !isConnecting) {
                Button(
                    onClick = onConnect,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("connect_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Link,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "CONNECT",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            } else {
                Button(
                    onClick = onDisconnect,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("disconnect_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.LinkOff,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "DISCONNECT",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            }
        }
    }
}

// =========================================================================
// SECTION: MODERN BATTERY CARD
// =========================================================================

@Composable
fun ModernBatteryCard(
    battery: BatteryInfo?,
    isLive: Boolean,
    modifier: Modifier = Modifier
) {
    val level = battery?.level
    val charging = battery?.charging

    // Light animated battery level
    val animatedLevel by androidx.compose.animation.core.animateFloatAsState(
        targetValue = (level ?: 0).toFloat(),
        animationSpec = androidx.compose.animation.core.tween(durationMillis = 600, easing = FastOutSlowInEasing),
        label = "animated_battery_level"
    )

    val chargingText = when (charging) {
        true -> "Charging"
        false -> "Discharging"
        null -> "N/A"
    }

    val chargingBadgeColor = when (charging) {
        true -> StatusOnline
        false -> MaterialTheme.colorScheme.primary
        null -> MaterialTheme.colorScheme.onSurfaceVariant
    }

    val levelColor = when {
        level == null -> MaterialTheme.colorScheme.onSurfaceVariant
        level <= 20 -> StatusOffline
        level <= 50 -> StatusWarning
        else -> StatusOnline
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("battery_telemetry_card")
            .alpha(if (isLive) 1f else 0.85f),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isLive) MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)
            else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Card Title & Charging Status Pill
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = if (charging == true) Icons.Default.BatteryChargingFull else Icons.Default.BatteryFull,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = "🔋 Battery",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = chargingBadgeColor.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, chargingBadgeColor.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (charging == true) {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = null,
                                tint = chargingBadgeColor,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        Text(
                            text = chargingText,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = chargingBadgeColor
                        )
                    }
                }
            }

            // Big Prominent Battery Percentage & Visual Gauge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = level?.let { "$it%" } ?: "N/A",
                        style = MaterialTheme.typography.displayMedium,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace,
                        color = levelColor,
                        modifier = Modifier.testTag("metric_battery_level")
                    )
                    Text(
                        text = if (charging == true) "Sedang mengisi daya" else "Menggunakan daya baterai",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Battery Meter Bar Gauge
                Surface(
                    modifier = Modifier.width(120.dp),
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        LinearProgressIndicator(
                            progress = { animatedLevel / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(12.dp)
                                .clip(RoundedCornerShape(6.dp)),
                            color = levelColor,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant,
                            strokeCap = StrokeCap.Round
                        )
                        Text(
                            text = level?.let { "$it / 100" } ?: "No Data",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 10.sp,
                            modifier = Modifier.align(Alignment.End)
                        )
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))

            // 4-Metric Grid: Temperature, Voltage, Current, Power
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                TelemetryMetricItem(
                    label = "Battery Temp",
                    value = battery?.temperature?.let { "$it°C" } ?: "N/A",
                    icon = Icons.Default.Thermostat,
                    modifier = Modifier.weight(1f),
                    testTag = "metric_battery_temp"
                )

                TelemetryMetricItem(
                    label = "Voltage",
                    value = battery?.voltage?.let { "$it V" } ?: "N/A",
                    icon = Icons.Default.Bolt,
                    modifier = Modifier.weight(1f),
                    testTag = "metric_voltage"
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                TelemetryMetricItem(
                    label = "Current",
                    value = battery?.current?.let { "$it mA" } ?: "N/A",
                    icon = Icons.Default.ElectricMeter,
                    modifier = Modifier.weight(1f),
                    testTag = "metric_current"
                )

                TelemetryMetricItem(
                    label = "Power",
                    value = battery?.power?.let { "$it W" } ?: "N/A",
                    icon = Icons.Default.Power,
                    modifier = Modifier.weight(1f),
                    testTag = "metric_power"
                )
            }
        }
    }
}

// =========================================================================
// SECTION: MODERN TEMPERATURE CARD
// =========================================================================

@Composable
fun ModernTemperatureCard(
    batteryTemp: Float?,
    thermal: ThermalInfo?,
    isLive: Boolean,
    modifier: Modifier = Modifier
) {
    val thermalStatus = thermal?.thermalStatus ?: "N/A"
    val thermalColor = when (thermalStatus) {
        "NORMAL" -> StatusOnline
        "LIGHT" -> MaterialTheme.colorScheme.primary
        "MODERATE", "SEVERE" -> StatusWarning
        "CRITICAL", "EMERGENCY", "SHUTDOWN" -> StatusOffline
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("thermal_telemetry_card")
            .alpha(if (isLive) 1f else 0.85f),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isLive) MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)
            else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Thermostat,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = "🌡 Temperature",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = thermalColor.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, thermalColor.copy(alpha = 0.4f))
                ) {
                    Text(
                        text = thermalStatus,
                        modifier = Modifier
                            .testTag("thermal_status_badge")
                            .padding(horizontal = 10.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = thermalColor
                    )
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))

            // Temperature Values: Battery, CPU, GPU, Thermal
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                TelemetryMetricItem(
                    label = "Battery",
                    value = (batteryTemp ?: thermal?.batteryTemperature)?.let { "$it°C" } ?: "N/A",
                    icon = Icons.Default.Thermostat,
                    modifier = Modifier.weight(1f),
                    testTag = "metric_temp_battery"
                )

                TelemetryMetricItem(
                    label = "CPU",
                    value = thermal?.cpuTemperature?.let { "$it°C" } ?: "N/A",
                    icon = Icons.Default.Thermostat,
                    modifier = Modifier.weight(1f),
                    testTag = "metric_cpu_temp"
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                TelemetryMetricItem(
                    label = "GPU",
                    value = thermal?.gpuTemperature?.let { "$it°C" } ?: "N/A",
                    icon = Icons.Default.Thermostat,
                    modifier = Modifier.weight(1f),
                    testTag = "metric_gpu_temp"
                )

                TelemetryMetricItem(
                    label = "Thermal",
                    value = thermalStatus,
                    icon = Icons.Default.Thermostat,
                    modifier = Modifier.weight(1f),
                    testTag = "metric_temp_thermal_status"
                )
            }
        }
    }
}

// =========================================================================
// SECTION: MODERN STATUS CARD (Charging, Battery Health, Thermal Status, Connection)
// =========================================================================

@Composable
fun ModernStatusOverviewCard(
    battery: BatteryInfo?,
    thermal: ThermalInfo?,
    connectionStatus: ConnectionStatus,
    latencyMs: Long?,
    isLive: Boolean,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("modern_status_overview_card")
            .alpha(if (isLive) 1f else 0.85f),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "Device Health & Status",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            // 4 Overview Badges Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // 1. Charging Status
                val charging = battery?.charging
                val isCharging = charging == true
                StatusIndicatorPill(
                    title = "Charging",
                    value = if (charging == true) "Charging" else if (charging == false) "Discharging" else "N/A",
                    icon = if (isCharging) Icons.Default.BatteryChargingFull else Icons.Default.BatteryAlert,
                    statusColor = if (isCharging) StatusOnline else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f),
                    testTag = "status_pill_charging"
                )

                // 2. Battery Health
                val health = battery?.health ?: "N/A"
                val healthColor = when (health) {
                    "GOOD" -> StatusOnline
                    "OVERHEAT", "DEAD", "OVER_VOLTAGE" -> StatusOffline
                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                }
                StatusIndicatorPill(
                    title = "Battery Health",
                    value = health,
                    icon = Icons.Default.HealthAndSafety,
                    statusColor = healthColor,
                    modifier = Modifier.weight(1f),
                    testTag = "status_pill_health"
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // 3. Thermal Status
                val thermalStatus = thermal?.thermalStatus ?: "N/A"
                val thermalColor = when (thermalStatus) {
                    "NORMAL" -> StatusOnline
                    "LIGHT" -> MaterialTheme.colorScheme.primary
                    "MODERATE", "SEVERE" -> StatusWarning
                    "CRITICAL", "EMERGENCY" -> StatusOffline
                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                }
                StatusIndicatorPill(
                    title = "Thermal Status",
                    value = thermalStatus,
                    icon = Icons.Default.Thermostat,
                    statusColor = thermalColor,
                    modifier = Modifier.weight(1f),
                    testTag = "status_pill_thermal"
                )

                // 4. Connection Status
                val connColor = when (connectionStatus) {
                    ConnectionStatus.CONNECTED -> StatusOnline
                    ConnectionStatus.CONNECTING, ConnectionStatus.RECONNECTING -> StatusWarning
                    ConnectionStatus.DISCONNECTED -> StatusOffline
                }
                val connText = when (connectionStatus) {
                    ConnectionStatus.CONNECTED -> if (latencyMs != null) "${latencyMs}ms Live" else "Online"
                    ConnectionStatus.CONNECTING -> "Connecting"
                    ConnectionStatus.RECONNECTING -> "Reconnecting"
                    ConnectionStatus.DISCONNECTED -> "Offline"
                }
                StatusIndicatorPill(
                    title = "Connection",
                    value = connText,
                    icon = if (connectionStatus == ConnectionStatus.CONNECTED) Icons.Default.Wifi else Icons.Default.WifiOff,
                    statusColor = connColor,
                    modifier = Modifier.weight(1f),
                    testTag = "status_pill_connection"
                )
            }
        }
    }
}

// =========================================================================
// REUSABLE TELEMETRY CARDS (For Monitor Mode preview)
// =========================================================================

@Composable
fun HardwareTelemetryCards(
    deviceStatus: DeviceStatus,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        ModernBatteryCard(battery = deviceStatus.battery, isLive = true)
        ModernTemperatureCard(batteryTemp = deviceStatus.battery?.temperature, thermal = deviceStatus.thermal, isLive = true)
        ModernStatusOverviewCard(
            battery = deviceStatus.battery,
            thermal = deviceStatus.thermal,
            connectionStatus = ConnectionStatus.CONNECTED,
            latencyMs = null,
            isLive = true
        )
    }
}

// =========================================================================
// REUSABLE TELEMETRY METRIC ITEM
// =========================================================================

@Composable
fun TelemetryMetricItem(
    label: String,
    value: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    testTag: String = "telemetry_metric_item"
) {
    Surface(
        modifier = modifier.testTag(testTag),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
            }

            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

// =========================================================================
// REUSABLE STATUS INDICATOR PILL
// =========================================================================

@Composable
fun StatusIndicatorPill(
    title: String,
    value: String,
    icon: ImageVector,
    statusColor: Color,
    modifier: Modifier = Modifier,
    testTag: String = "status_indicator_pill"
) {
    Surface(
        modifier = modifier.testTag(testTag),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        border = androidx.compose.foundation.BorderStroke(1.dp, statusColor.copy(alpha = 0.25f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(statusColor)
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp
                )
            }

            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1
            )
        }
    }
}

// =========================================================================
// SECTION: RAW JSON & RESPONSE DIAGNOSTICS CARD
// =========================================================================

@Composable
fun RawResponseCard(
    rawResponse: String?,
    timestamp: Long?,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    onCopy: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("raw_response_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.25f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "Diagnostics & Raw Response",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isExpanded && rawResponse != null) {
                        IconButton(
                            onClick = onCopy,
                            modifier = Modifier.size(32.dp).testTag("btn_copy_raw_json")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy JSON",
                                modifier = Modifier.size(16.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    IconButton(
                        onClick = onToggleExpand,
                        modifier = Modifier.size(32.dp).testTag("btn_toggle_raw_json")
                    ) {
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = "Expand Raw JSON",
                            modifier = Modifier.size(20.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible = isExpanded,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (timestamp != null) {
                        val formatted = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault()).format(Date(timestamp))
                        Text(
                            text = "Server Timestamp: $formatted ($timestamp)",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ) {
                        Text(
                            text = rawResponse ?: "Belum ada response dari HP 1",
                            modifier = Modifier
                                .padding(12.dp)
                                .testTag("raw_response_text"),
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

private fun copyToClipboard(context: Context, text: String, toastMessage: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText("PhoneLink Status", text)
    clipboard.setPrimaryClip(clip)
    Toast.makeText(context, toastMessage, Toast.LENGTH_SHORT).show()
}
