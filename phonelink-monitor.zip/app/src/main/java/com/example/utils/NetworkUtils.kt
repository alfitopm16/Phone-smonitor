package com.example.utils

import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections

object NetworkUtils {

    data class NetworkIpInfo(
        val ip: String,
        val interfaceName: String,
        val isHotspotOrWifi: Boolean
    )

    /**
     * Retrieves all valid IPv4 non-loopback addresses from all active network interfaces.
     */
    fun getLocalIpDetails(): List<NetworkIpInfo> {
        val result = mutableListOf<NetworkIpInfo>()
        try {
            val netInterfaces = NetworkInterface.getNetworkInterfaces()
            val interfaces = if (netInterfaces != null) Collections.list(netInterfaces) else emptyList()
            for (intf in interfaces) {
                if (intf == null || !intf.isUp || intf.isLoopback) continue
                val inetAddrs = intf.inetAddresses
                val addrs = if (inetAddrs != null) Collections.list(inetAddrs) else emptyList()
                for (addr in addrs) {
                    if (addr != null && !addr.isLoopbackAddress && addr is Inet4Address) {
                        val hostAddress = addr.hostAddress ?: continue
                        if (hostAddress.isNotEmpty() && !hostAddress.startsWith("127.")) {
                            val name = (intf.name ?: "").lowercase()
                            val isHotspotOrWifi = name.contains("wlan") ||
                                    name.contains("ap") ||
                                    name.contains("swlan") ||
                                    name.contains("rndis") ||
                                    name.contains("eth") ||
                                    hostAddress.startsWith("192.168.") ||
                                    hostAddress.startsWith("10.") ||
                                    hostAddress.startsWith("172.")
                            result.add(
                                NetworkIpInfo(
                                    ip = hostAddress,
                                    interfaceName = intf.name ?: "eth0",
                                    isHotspotOrWifi = isHotspotOrWifi
                                )
                            )
                        }
                    }
                }
            }
        } catch (e: Throwable) {
            e.printStackTrace()
        }

        // Sort so that wlan/ap/192.168.43.x addresses appear first
        return result.sortedWith(
            compareByDescending<NetworkIpInfo> { it.ip.startsWith("192.168.43.") }
                .thenByDescending { it.interfaceName.startsWith("ap") }
                .thenByDescending { it.interfaceName.startsWith("wlan") }
                .thenBy { it.ip }
        )
    }

    /**
     * Get simple list of active IP strings.
     */
    fun getLocalIpAddresses(): List<String> {
        val details = getLocalIpDetails()
        val ips = details.map { it.ip }.distinct()
        return if (ips.isEmpty()) {
            listOf("192.168.43.1") // Android standard hotspot default IP
        } else {
            ips
        }
    }
}
