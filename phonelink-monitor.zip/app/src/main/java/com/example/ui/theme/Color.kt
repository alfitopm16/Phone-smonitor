package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary & Secondary Accents
val Cyan40 = Color(0xFF0284C7)
val Cyan80 = Color(0xFF38BDF8)
val Teal40 = Color(0xFF0D9488)
val Teal80 = Color(0xFF2DD4BF)

val SlateDarkBackground = Color(0xFF0B0F17)
val SlateDarkSurface = Color(0xFF131B2A)
val SlateDarkSurfaceVariant = Color(0xFF1E293B)

val SlateLightBackground = Color(0xFFF8FAFC)
val SlateLightSurface = Color(0xFFFFFFFF)
val SlateLightSurfaceVariant = Color(0xFFF1F5F9)

// Status colors
val StatusOnline = Color(0xFF10B981)
val StatusOffline = Color(0xFFEF4444)
val StatusWarning = Color(0xFFF59E0B)
